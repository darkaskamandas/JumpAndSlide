﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Player_Name_Tag : MonoBehaviour
{
    /*
        [Serializable] private TextMeshProUGUI nameText;

        private void Start()
        {
            if (PhotonView.IsMine) { return; }

            SetName();
        }
        private void SetName() => nameText.text = PhotonView.Owner.NickName;
    }
    */
}